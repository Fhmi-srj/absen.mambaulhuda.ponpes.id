<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class PrintIzinController extends Controller
{
    public function index()
    {
        return view('user.print-izin');
    }
}
